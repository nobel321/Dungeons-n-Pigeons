using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Combat : MonoBehaviour
{
    public bool canAttack; // use animation events to trigger canAttack (true/false)
    Animator anim;

    // Change system to incorporate animation based on object it is placed on

    private void Start()
    {
        anim = GetComponent<Animator>();
        canAttack = true;
    }

    // Update is called once per frame
    void Update()
    {
        if (canAttack == true)
        {
            if (Input.GetKey(KeyCode.J))
            {
                Attack(1);
            }
        }
    }

    public void Attack(int n)
    {
        anim.SetTrigger("Attack" + n.ToString());
    }

    public void startAttack()
    {
        canAttack = false;
    }

    public void endAttack()
    {
        canAttack = true;
    }

    private void OnTriggerEnter(Collider other)
    {
        
    }
}
